import java.sql.*;

public class JdbcCode
{   public static Statement st =null;
    public static Statement code()
     { 
       try
       {
       DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
       Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","12345");
       st = con.createStatement();
       
       }
       catch(Exception ex) 
       { 
        System.out.println(ex);
        
       }
        return st;
     }
}
    

