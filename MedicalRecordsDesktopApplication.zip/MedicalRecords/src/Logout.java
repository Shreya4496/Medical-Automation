
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Logout implements ActionListener{
     String str;
     JFrame f = new JFrame(); 
    JLabel l= new JLabel("Are you sure you want to logout");
    JButton b1 = new JButton("YES");
    JButton b2 = new JButton("NO");
    
    
    
    public Logout(String a)
    { str=a;
      f.add(l);
      f.add(b1);
      f.add(b2);
      f.setLayout(new GridLayout(3,1,2,2));
      f.setVisible(true);
      f.setTitle("logout ");
      f.setSize(200,200);
      f.setLocation(200,200);
      b1.addActionListener(this);
      b2.addActionListener(this);
      
      
    }
    public void actionPerformed(ActionEvent e)
    { if (e.getSource()==b1)
    { JOptionPane.showMessageDialog(f,"You're successfully logged out ");
      f.setVisible(false);
      new main();
      
    
    }
    else if(e.getSource()==b2)
    { 
      f.setVisible(false);
      new Option(str);
    
    
    }
    }
}