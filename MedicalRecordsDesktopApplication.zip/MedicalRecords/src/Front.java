/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.JOptionPane.*;

public class Front
{
    public static void main(String args[])
    {
        Front1 k= new Front1();
    }
}

class Front1 implements ActionListener
{
    JFrame f = new JFrame();
    JButton l1 = new JButton("Doctor Login");
    JButton l2 = new JButton("Patient Login");
    JLabel l0= new JLabel("***WELCOME TO LOGIN PAGE***");
    
    public Front1()
    { f.add(l0);
      f.add(l1);
      f.add(l2);
      f.setLayout(new FlowLayout());
      f.setVisible(true);
      f.setTitle("WELCOME ! ");
      f.setSize(500,500);
      f.setLocation(200,200);
      l1.addActionListener(this);
      l2.addActionListener(this);
      
    }
    public void actionPerformed(ActionEvent e)
    { if (e.getSource()==l1)
    { JOptionPane.showMessageDialog(f,"You're in doctor mode ");
     // f.setVisible(false);
      new main();
    
    }
    else if(e.getSource()==l2)
    { JOptionPane.showMessageDialog(f,"You're in patient mode ");
    // f.setVisible(false);
     new UserLogin();
    
    }
    f.pack();
    }
        
        
    
}  


