
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static oracle.net.aso.C11.l;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Option extends JLabel implements ActionListener  {
     String name1;
     JFrame f = new JFrame(); 
     Label l= new Label(" ");
  //  JButton b1 = new JButton("Show All Patients");
    JButton b2 = new JButton("Delete a Patient Detail");
    JButton b3 = new JButton("Add A Patient");
    JButton b5 = new JButton("Update Patient Details");
    JButton b4 = new JButton("LOGOUT");
    
    
    public Option(String name)
    { this.name1=name;
      l.setText("Welcome "+name1+"");
      f.add(l);
      //f.add(b1);
      f.add(b2);
      f.add(b3);
      
      f.add(b5);
      f.add(b4);
      f.setLayout(new GridLayout(5,1,2,2));
      f.setVisible(true);
      f.setTitle("ROLES OF ADMIN ");
      f.setSize(500,500);
      f.setLocation(200,200);
    //  b1.addActionListener(this);
      b2.addActionListener(this);
      b3.addActionListener(this);
      b4.addActionListener(this);
      b5.addActionListener(this);
    }
 
 public void actionPerformed(ActionEvent e)
    { /*if (e.getSource()==b1)
    { 
      f.setVisible(false);
      new ShowAll(name1);
    
    }*/
    if(e.getSource()==b2)
    { 
      new DeleteAccount(name1);
      f.setVisible(false);
    
    
    }
    else if(e.getSource()==b3)
    { new CreateAccount(name1);
     f.setVisible(false);
    
    }
    
    else if(e.getSource()==b4)
    { new Logout(name1);
      f.setVisible(false);
     
    }
      else if(e.getSource()==b5)
    {  new Update(name1);
      f.setVisible(false);
     
    }
    }
    
    
    
}
