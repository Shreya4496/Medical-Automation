
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.TextField;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.JOptionPane.*;
import java.applet.*;
import java.sql.Statement;

public class AdminRegister implements ActionListener {
    
    JFrame f = new JFrame();
    //JLabel l= new JLabel(" *** Enter Your Details *** ");
    JLabel l1= new JLabel("Name : ");
    JLabel l2= new JLabel("Doctor ID : ");
    JLabel l3= new JLabel("Speciality : ");
    JLabel l4= new JLabel("Password : ");
    JLabel l5= new JLabel("Confirm Password : ");
    JTextField t1 = new JTextField(20);
    JTextField t2 = new JTextField(20);
    JTextField t3 = new JTextField(20);
    TextField t4 = new TextField(20);
    TextField t5 = new TextField(20);
     
    JButton b1 = new JButton("Submit");
    JButton b2 = new JButton("Reset");
    
    public  AdminRegister()
    { //f.add(l);
       t4.setEchoChar('*');
      t5.setEchoChar('*');
      f.add(l1);
      f.add(t1);
      f.add(l2);
      f.add(t2);
      f.add(l3);
      f.add(t3);
      f.add(l4);
      f.add(t4);
      f.add(l5);
      f.add(t5);
      f.add(b1);
      f.add(b2);
      
      f.setLayout(new GridLayout(7,2,2,2));
      f.setVisible(true);
      f.setTitle("REGISTER Page");
      f.setSize(500,500);
      f.setLocation(200,200);
      b1.addActionListener(this);
      b2.addActionListener(this);
           
     
    }
    
     
  /*  public void paint(Graphics g)
    {
        g.drawString("*** Enter Your Details ***",10,20);
    }
*/  

    public void actionPerformed(ActionEvent e)
    { if (e.getSource()==b1)
    { 
      String str[]=new String[5];
      str[0]=t1.getText();
      String max=t2.getText();
      str[2]=t3.getText();
      String max1=t4.getText();
      str[4]=t5.getText();
      
      if(max1.equals(str[4]))
      {
       String name =JOptionPane.showInputDialog("Enter the security key (2 Chances) ");
       if(name.equals("hcl"))
       {
           JOptionPane.showMessageDialog(f,"Congratulation you're now a doctor in this hospital");
          // String sql="insert into AdminTable values('"+str[1]+",'"+str[3]+"')";
          String sql="insert into Doc values('"+str[0]+"','"+max+"','"+str[2]+"','"+max1+"')";
           try
           {
               Statement st = JdbcCode.code();
           int m=st.executeUpdate(sql);
           f.setVisible(false);
           new main();
           
           }
           catch(Exception ex)
           {JOptionPane.showMessageDialog(f,"Sorry there is some technical fault");
            new AdminRegister();
            
           }
           
       }
      else
       {
         JOptionPane.showMessageDialog(f,"INVALID Security key Enter again ");
         String name1 =JOptionPane.showInputDialog("Enter the security key (1 Chance) ");
       if(name1.equals("hcl"))
       {
           JOptionPane.showMessageDialog(f,"Congratulation you're now a doctor in this hospital");
         //  String sql="insert into AdminTable values('"+str[1]+"','"+str[3]+"')";
          // String sql="insert into AdminTable values('"+max+"','"+max1+"','"+speciality+"')";
            String sql="insert into Doc values('"+str[0]+"','"+max+"','"+str[2]+"','"+max1+"')";
           try
           {
               Statement st = JdbcCode.code();
           int m=st.executeUpdate(sql);
           new main();
           }
           catch(Exception ex)
           {JOptionPane.showMessageDialog(f,"Sorry there is some technical fault");
            new AdminRegister();
            
           }
           
         
       }
       else
       {
           
           JOptionPane.showMessageDialog(f,"INVALID Security key, Access Denied.. ");
           f.setVisible(false);
           new Front1();
       }
      }
      }
      else
      {
          JOptionPane.showMessageDialog(f,"The password is not matched");
          t4.setText(null);
          t5.setText(null);
      }
    
    }
    
    else if(e.getSource()==b2)
    {
      t1.setText(null);
      t2.setText(null);
      t3.setText(null);
      t4.setText(null);
      t5.setText(null);
    
    
    }
    } 
    
}

