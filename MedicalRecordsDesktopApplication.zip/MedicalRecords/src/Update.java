
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Update implements ActionListener{
    String name;
   JFrame frame= new JFrame("Update Page");
    JLabel l1 =new JLabel("ENTER Patient Id.");
     JTextField t1 =new JTextField(20);
     JButton b1 =new JButton("BACK");
    JButton b2=new JButton("Submit");
    public Update(String name)
    {  this.name=name;
      // t2.setEchoChar('*');
       frame.add(l1);
       frame.add(t1);
      
       frame.add(b1);
       frame.add(b2);
       b1.addActionListener(this);
       
       b2.addActionListener(this);
       frame.setLayout(new GridLayout(3,2,1,1));
       frame.setLocation(400,200);
       frame.setVisible(true);
       frame.setSize(400,400);
      }
    public void  actionPerformed(ActionEvent e)
    {
     if(e.getSource()==b2)
     { 
   /*try   
      {
      int a =Integer.parseInt(t1.getText());
      String sql = "select * from Patient where password='"+a+"'";
      String accn= t1.getText();
     // String max1= t2.getText();
      Statement st = JdbcCode.code();
      ResultSet rs = st.executeQuery(sql); 
      if(rs.next())
      {
        //  JOptionPane.showMessageDialog(frame,"YOU HAVE SUCCESSFULLY LOGGED IN");
          frame.setVisible(false);
          new UpdateUser(a,name);
      }
       else
      { 
           JOptionPane.showMessageDialog( frame,"INVALID ENTERED LOGIN CREDENTIALS,PLEASE CHECK YOUR ENTERED DETAILS AGAIN ");
           frame.setVisible(false);
           new Update(name);
      }
      }
     
   catch(Exception ex)
     { JOptionPane.showMessageDialog( frame,"INVALID ENTERED LOGIN CREDENTIALS,PLEASE CHECK YOUR ENTERED DETAILS AGAIN ");
       frame.setVisible(false);
       new Update(name);
      }*/
         new UpdateUser(Integer.parseInt(t1.getText()), name);
      }
     else if (e.getSource()==b1)
     {
         new Option(name);
     }
    
}
}
