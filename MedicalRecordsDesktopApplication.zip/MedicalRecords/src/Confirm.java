
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Statement;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Confirm implements ActionListener
{
    
       String str,aacn;
     JFrame f = new JFrame(); 
    JLabel l= new JLabel("Are you sure you want to delete the selected record");
    JButton b1 = new JButton("YES");
    JButton b2 = new JButton("NO");
    
    
    
    public Confirm(String a,String userid)
    { str=a;
      this.aacn=userid;
      f.add(l);
      f.add(b1);
      f.add(b2);
      f.setLayout(new GridLayout(3,1,2,2));
      f.setVisible(true);
      f.setTitle("delete record");
      f.setSize(200,200);
      f.setLocation(200,200);
      b1.addActionListener(this);
      b2.addActionListener(this);
      
      
    }//String data = null;
    public void actionPerformed(ActionEvent e)
    { if (e.getSource()==b1)
    
    {     
          JOptionPane.showMessageDialog(f,"You have succesfully deleted the "+aacn+" record ");
          String sql="delete from Cust where account_no='"+aacn+"'";
          
           try
           {
               Statement st = JdbcCode.code();
           int m=st.executeUpdate(sql);
               new Option(str);
           
           }
           catch(Exception ex)
           {JOptionPane.showMessageDialog(f,"Sorry there is some technical fault");
            new AdminRegister();
            
           }
           
        
      
      f.setVisible(false);
      
      
    
    }
    else if(e.getSource()==b2)
    { 
      f.setVisible(false);
      new Option(str);
    
    
    }
    }
}
    
    

