
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class DeleteAccount implements ActionListener

{
    String name;
    JFrame f = new JFrame();
    //JLabel l= new JLabel(" *** Enter Your Details *** ");
    JLabel l1= new JLabel("Enter PatientId to be deleted");
    
    JTextField t1 = new JTextField(20);
       
    JButton b1 = new JButton("Yes");
    JButton b2 = new JButton("Back");
    
    DeleteAccount(String name)
    {   this.name=name;
        f.add(l1);
        f.add(t1);
        f.add(b1);
        f.add(b2);
        f.setLayout(new GridLayout(2,2,2,2));
        f.setVisible(true);
        f.setTitle("DELETE Record");
        f.setSize(500,500);
        f.setLocation(200,200);
        b1.addActionListener(this);
        b2.addActionListener(this);
    }
    String a=t1.getText();
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1)
        {   String a=t1.getText();
          new Confirm(name,a);
          
          f.setVisible(false);
        }
        else if(e.getSource()==b2)
        {    f.setVisible(false);
            new Option(name);
        }
    
}
}
