
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class UpdateUser implements ActionListener{
int a;
  String name;
    JFrame frame= new JFrame("USER");
    JLabel l1 =new JLabel("Name");
    JLabel l2 =new JLabel("Patient Id");
    JLabel l3 =new JLabel("Diagonsis");
    
    JTextField t1 =new JTextField(20);
    TextField t2 =new TextField(20);
     TextField t3 =new TextField(20);
    JButton b1 =new JButton("Update");
    JButton b2 =new JButton("BACK");
    public UpdateUser(int a,String name)
    {  this.a=a;
       this.name=name;
       frame.add(l1);
       frame.add(t1);
       frame.add(l2);
       frame.add(t2);
       frame.add(l3);
       frame.add(t3);
       frame.add(b1);
       frame.add(b2);
       b1.addActionListener(this);
       b2.addActionListener(this);
       frame.setLayout(new GridLayout(4,2,1,1));
       frame.setLocation(400,200);
       frame.setVisible(true);
       frame.setSize(400,400);
      }
    public void  actionPerformed(ActionEvent e)
    {
     if(e.getSource()==b1)
     { 
   try   
      {
      String max= t1.getText();
      String max1= t2.getText();
      String max3= t3.getText();
      int a =Integer.parseInt(max);
      String sql = "update Patient set type='"+max3+"' where resadd=345";
      Statement st = JdbcCode.code();
     // ResultSet rs =
              int m=st.executeUpdate(sql); 
      
          JOptionPane.showMessageDialog(frame,"YOU HAVE SUCCESSFULLY Updated");
          frame.setVisible(false);
          new user(a);
      
      /* else
      { 
           JOptionPane.showMessageDialog( frame,"INVALID ENTRY");
           frame.setVisible(false);
           new UpdateUser(a,name);
      }*/
      }
     
   catch(Exception ex)
     { JOptionPane.showMessageDialog( frame,"INVALID ENTRY ");
       frame.setVisible(false);
       new UpdateUser(a,name);
      }
      }
     else if(e.getSource()==b2)
     {   frame.setVisible(false);
          new Update(name);
        }
    }
}

    

