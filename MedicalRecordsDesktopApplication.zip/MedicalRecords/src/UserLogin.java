

import java.awt.GridLayout;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import java.awt.TextField;

public class UserLogin implements ActionListener
{
    JFrame frame= new JFrame("USER LOGIN PAGE");
    JLabel l1 =new JLabel("ENTER PatientId.");
  //  JLabel l2 =new JLabel("ENTER PASSWORD");
    JTextField t1 =new JTextField(20);
  //  TextField t2 =new TextField(20);
    JButton b1 =new JButton("LOG IN");
    JButton b2 =new JButton("BACK");
    public UserLogin()
    {  
      // t2.setEchoChar('*');
       frame.add(l1);
       frame.add(t1);
      // frame.add(l2);
      // frame.add(t2);
       frame.add(b1);
       frame.add(b2);
       b1.addActionListener(this);
       b2.addActionListener(this);
       frame.setLayout(new GridLayout(3,2,1,1));
       frame.setLocation(400,200);
       frame.setVisible(true);
       frame.setSize(400,400);
      }
    public void  actionPerformed(ActionEvent e)
    {
     if(e.getSource()==b1)
     { 
   try   
      {
      String max= t1.getText();
     // String max1= t2.getText();
      int a =Integer.parseInt(max);
      String sql = "select * from Patient where resadd="+a+"";
      Statement st = JdbcCode.code();
      ResultSet rs = st.executeQuery(sql); 
      if(rs.next())
      {
          JOptionPane.showMessageDialog(frame,"YOU HAVE SUCCESSFULLY LOGGED IN");
          frame.setVisible(false);
          new detail(a);
      }
       else
      { 
           JOptionPane.showMessageDialog( frame,"INVALID ENTERED LOGIN CREDENTIALS,PLEASE CHECK YOUR ENTERED DETAILS AGAIN ");
           frame.setVisible(false);
           new UserLogin();
      }
      }
     
   catch(Exception ex)
     { JOptionPane.showMessageDialog( frame,"INVALID ENTERED LOGIN CREDENTIALS,PLEASE CHECK YOUR ENTERED DETAILS AGAIN ");
       frame.setVisible(false);
       new UserLogin();
      }
      }
     else if(e.getSource()==b2)
     {   frame.setVisible(false);
          new Front();
        }
    }
}
