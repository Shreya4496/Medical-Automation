
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class main implements ActionListener {
    
   
      JFrame f = new JFrame();
      JLabel l1= new JLabel(" Enter your Doctor ID ");
      JLabel l2= new JLabel(" Enter password ");
      JTextField t1 = new JTextField(20);
      TextField t2 = new TextField(20);

    JButton b1 = new JButton("LOGIN");
    JButton b2 = new JButton("REGISTER");
    JLabel l0= new JLabel(" *** WELCOME *** ");
    
     public main()
    { t2.setEchoChar('*');
      f.add(l1);
      f.add(t1);
      f.add(l2);
      f.add(t2);
      f.add(b1);
      f.add(b2);
      f.setLayout(new GridLayout(3,1,2,2));
      f.setVisible(true);
      f.setTitle("Doctor Page");
      f.setSize(500,500);
      f.setLocation(200,200);
      b1.addActionListener(this);
      b2.addActionListener(this);
      
    }
    public void actionPerformed(ActionEvent e)
    { if (e.getSource()==b2)
    { f.setVisible(false);
      new AdminRegister();
    
    }
    else if(e.getSource()==b1)
    { 
     String max= t1.getText();
     String max1= t2.getText();
    String sql= "select DocId from Doc where DocId='"+max+"' and pass='"+max1+"'";
    try
    {
      Statement st = JdbcCode.code();
      ResultSet rs = st.executeQuery(sql); 
      if(rs.next())
      {JOptionPane.showMessageDialog(f,"YOU HAVE SUCCESSFULLY LOGGED IN");
      new Option(max);
      }
      else
      {JOptionPane.showMessageDialog( f,"INVALID ENTERED LOGIN CREDENTIALS,PLEASE CHECK YOUR ENTERED DETAIL AGAIN ");
       new main();
      }       f.setVisible(false);

      f.setVisible(false);
      //new ABC(max);
    }
    catch (Exception ex)
    {
        JOptionPane.showMessageDialog( f,"ENTERED LOGIN CREDENTIALS,PLEASE CHECK YOUR ENTERED DETAILS AGAIN ");
         f.setVisible(false);
        new main();
    }
    }
    }
        
          
    }
    
    
    

