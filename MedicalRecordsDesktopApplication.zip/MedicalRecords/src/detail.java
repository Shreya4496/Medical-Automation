
import java.awt.GridLayout;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
public class detail implements ActionListener
{
    int acc;
    JFrame frame = new JFrame("LOGGED IN PATIENT DETAILS"+acc+"");
    JLabel l1 = new JLabel("NAME ");
    JLabel l2 = new JLabel("PATIENT ID:");
    JLabel l3 = new JLabel("DETAILS");
    //JLabel l4 = new JLabel("RESIDENTIAL ADDRESS");
    //JLabel l5 = new JLabel("PHONE NUMBER");
  
    JTextField t1 = new JTextField(20);
    JTextField t2 = new JTextField(20);
    JTextField t3 = new JTextField(20);
    
          
    JButton b = new JButton("BACK");
    
    public detail(int a) 
    {
        acc = a;
         frame.add(l1);
        frame.add(t1);
        frame.add(l2);
        frame.add(t2);
        frame.add(l3);
        frame.add(t3);
       
        frame.add(b);
        frame.setLayout(new GridLayout(6,2,1,1));
        frame.setLocation(400,200);
        frame.setVisible(true);
        frame.setSize(400,400);
        String data[][]= new String[20][4];
        String sql = "select* from Patient where resadd="+a+"";
        Statement st = JdbcCode.code();
        try
        {
         ResultSet rs = st.executeQuery(sql);
         int i=0;
         while(rs.next())
         {
          data[i][0]=rs.getString(1);
          data[i][1]=""+rs.getInt(2);
          data[i][2]=rs.getString(3);
          data[i][3]=rs.getString(4);
           i++;
         }
         t1.setText(data[0][0]);
         t2.setText(data[0][1]);
         t3.setText(data[0][3]);
       
         b.addActionListener(this);
       
        }
        catch(Exception ex)
        {
          JOptionPane.showMessageDialog(frame,ex);
        }
        
    }
    
    public void actionPerformed(ActionEvent e)
    {
     if(e.getSource()==b)
     {
      frame.setVisible(false);
      new UserLogin();
     }
     
    }
}
