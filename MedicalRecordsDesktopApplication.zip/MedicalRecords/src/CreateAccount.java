
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class CreateAccount implements ActionListener{
    
      JFrame f = new JFrame();
     // JLabel l1= new JLabel(" Enter the customers's details");
      JLabel l2= new JLabel(" Name");
      JLabel l3= new JLabel(" PatientId");
      JLabel l4= new JLabel(" Phone No ");
      JLabel l5= new JLabel(" Medical History");
    //   JLabel l6= new JLabel(" DoctorId");
      JTextField t1 = new JTextField(20);
      JTextField t2 = new JTextField(20);
      JTextField t3 = new JTextField(20);
      JTextField t4 = new JTextField(20);
      //JTextField t5 = new JTextField(20);
      //JTextField t6= new JTextField(20);

    JButton b1 = new JButton("ADD");
    JButton b2 = new JButton("CLEAR");
    JButton b3 = new JButton("BACK");
     String admin;
    public CreateAccount(String Adminid) {
        admin=Adminid;
        
        
      //f.add(l1);
      f.add(l2);
      f.add(t1);   
      
      f.add(l3);
            
      f.add(t2);
      f.add(l4);      
      f.add(t3);
      f.add(l5);
      f.add(t4);
      f.add(b1);
      f.add(b2);
      f.add(b3);
      f.setLayout(new GridLayout(6,3,1,1));
      f.setVisible(true);
      f.setTitle(" REGISTER ");
      f.setSize(500,500);
      f.setLocation(200,200);
      b1.addActionListener(this);
      b2.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      if(e.getSource()==b1)
      {
          String name,type;
          int resadd;
          String phone;
          name = t1.getText();
          resadd = Integer.parseInt(t2.getText());
           phone= t3.getText();
         // phone = Integer.parseInt(p);
          type=t4.getText();
          Statement st = JdbcCode.code();
         /* String sql1=" select count(*) from temp";
          
          try {
             
              
          try {
              rs = st.executeQuery(sql1);
          } catch (SQLException ex) {
              Logger.getLogger(CreateAccount.class.getName()).log(Level.SEVERE, null, ex);
          }
              
              
               while(rs.next())
        {
            for(int i=1;i<=1;i++)
            {
                row=rs.getString(i);
                
            }
        }      
               String sql2=" select * from temp";
               try {
             
              ResultSet rs2 = st.executeQuery(sql2);
              
              
                int row1=Integer.parseInt(row);
                data=rs2.getString(row1);
                
     
               
              int aacn=0;
               aacn=Integer.parseInt(data);
               aacn++;
           //   int m=Integer.parseInt(p);
           */
         try
         {
             String sql1="select * from temp";
         ResultSet rSet =  st.executeQuery(sql1);
        
         /*  rSet.last(); 
           int total = rSet.getRow();
           rSet.beforeFirst();
          int aacn;
          aacn=total+1;
          String aacn1=null;
           aacn1 = Integer.toString(aacn);*/
         int num_rows=0;
         while (rSet.next())
{

    num_rows++;
}
        /*  
          JOptionPane.showMessageDialog(f,"Congrats The record is been created , the account no. generated is "+num_rows+"");
          String sqltemp="insert into temp values ('"+num_rows+"')";
          st.executeUpdate(sqltemp);*/
          String sql="insert into Patient values('"+name+"',"+resadd+",'"+phone+"','"+type+"')";
           st.executeUpdate(sql);
              
          
          }
          catch (SQLException ex) {
              Logger.getLogger(CreateAccount.class.getName()).log(Level.SEVERE, null, ex);
          }
         f.setVisible(false);
         new Option(admin);
          }
               
          
          
      
      else if(e.getSource()==b2)
      {
          t1.setText(null);
          t2.setText(null);
          t3.setText(null);
          t4.setText(null);
      }
      else if(e.getSource()==b3)
      {   f.setVisible(false);
          new Option(admin);
      }
    }
    
    
}

